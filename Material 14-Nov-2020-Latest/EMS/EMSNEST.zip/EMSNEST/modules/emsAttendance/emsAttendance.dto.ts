
export interface emsAttendanceCreateDto  {
    empId: string,
    userName: string,
    empName: string,
    designation: string,
    attendance: string,
}