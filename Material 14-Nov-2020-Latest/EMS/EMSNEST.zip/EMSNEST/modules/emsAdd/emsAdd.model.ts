import { Document } from 'mongoose';

export interface EmsAdd extends Document  {
    userName: string;
    password: string;
    retypePassword: string;
    fullName: string;
    sex: object;
    nationality: string;
    martialStatus: string;
    dob:object;
    joiningDate: object;
    bloodGroup: object;
    policy: boolean;
    slider: object;
    contactNumber:number;
    personalEmail: string;
    designation: string;
    address: string;
    city: string;
    pinCode:number;
}