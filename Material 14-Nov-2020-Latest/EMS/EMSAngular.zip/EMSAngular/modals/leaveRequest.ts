export class emsLeaveRequestModal {
    userName: string;
    leaveType: string;
    fromDate: string;
    toDate: string;
    noOfDays: string;
    leaveReason: string;
    leaveStatus: string;
}