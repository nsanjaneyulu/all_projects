export class emsAddModal {
    userName: string;
    password: string;
    retypePassword: string;
    fullName: string;
    sex: string;
    nationality: string;
    martialStatus: string;
    dob: string;
    bloodGroup: string;
    contactNumber:number;
    personalEmail: string;
    designation: string;
    address: string;
    city: string;
    pinCode:number;
}